﻿using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SocialPlatforms;
using UnityEngine.SceneManagement;

public class OfflineGameBehaviour : MonoBehaviour
{
    private Vector3 startMousePos;
    private LineRenderer instantiatedLine;
    private List<GameObject> pointList;
    private List<LineRenderer> alreadyDrawnLineList;
    private Color currentPlayerColor;
    private LineRenderer currentPlayerLine;
    private bool isLineGameState;
    private Image newPoint;
    private List<List<LineRenderer>> foundPolygons;
    private Vector3 secondPointCandidate = new Vector3(0f, 0f, -10000f);
    private List<LineRenderer> selectedLines;

    private readonly string lineGameStateLabel = "Choose a line!";
    private readonly string polygonCheckStageLabel = "Choose polygons!";


    [SerializeField]
    private GameObject parentObject;

    [SerializeField]
    private GameObject pointGenerator;

    [SerializeField]
    private GameObject lineGenerator;

    [SerializeField]
    private TextMeshProUGUI playerOnePoints;

    [SerializeField]
    private TextMeshProUGUI playerTwoPoints;

    [SerializeField]
    private TextMeshProUGUI gameStageLabel;

    [SerializeField]
    private GameObject checkPolygonButton;

    [SerializeField]
    private GameObject dialoguePanel;

    [SerializeField]
    private Button dialogueBtn;

    [SerializeField]
    private TextMeshProUGUI dialogueText;

    [SerializeField]
    private GameObject settingsPanel;

    public Vector3 StartMousePos { get => startMousePos; set => startMousePos = value; }
    public LineRenderer InstantiatedLine { get => instantiatedLine; set => instantiatedLine = value; }
    public List<GameObject> PointList { get => pointList; set => pointList = value; }
    public List<LineRenderer> AlreadyDrawnLineList { get => alreadyDrawnLineList; set => alreadyDrawnLineList = value; }
    public Color CurrentPlayerColor { get => currentPlayerColor; set => currentPlayerColor = value; }
    public LineRenderer CurrentPlayerLine { get => currentPlayerLine; set => currentPlayerLine = value; }
    public bool IsLineGameState { get => isLineGameState; set => isLineGameState = value; }
    public Image NewPoint { get => newPoint; set => newPoint = value; }
    public List<List<LineRenderer>> FoundPolygons { get => foundPolygons; set => foundPolygons = value; }
    public List<LineRenderer> SelectedLines { get => selectedLines; set => selectedLines = value; }
    public GameObject ParentObject { get => parentObject; set => parentObject = value; }
    public GameObject PointGenerator { get => pointGenerator; set => pointGenerator = value; }
    public GameObject LineGenerator { get => lineGenerator; set => lineGenerator = value; }
    public TextMeshProUGUI PlayerOnePoints { get => playerOnePoints; set => playerOnePoints = value; }
    public TextMeshProUGUI PlayerTwoPoints { get => playerTwoPoints; set => playerTwoPoints = value; }
    public TextMeshProUGUI GameStageLabel { get => gameStageLabel; set => gameStageLabel = value; }
    public GameObject CheckPolygonButton { get => checkPolygonButton; set => checkPolygonButton = value; }
    public GameObject DialoguePanel { get => dialoguePanel; set => dialoguePanel = value; }
    public Button DialogueBtn { get => dialogueBtn; set => dialogueBtn = value; }
    public TextMeshProUGUI DialogueText { get => dialogueText; set => dialogueText = value; }
    public GameObject SettingsPanel { get => settingsPanel; set => settingsPanel = value; }

    // Start is called before the first frame update
    public void Start()
    {
        CheckPolygonButton.SetActive(false);
        DialoguePanel.SetActive(false);
        SettingsPanel.SetActive(false);

        FoundPolygons = new List<List<LineRenderer>>();
        AlreadyDrawnLineList = new List<LineRenderer>();
        SelectedLines = new List<LineRenderer>();

        IsLineGameState = true;
        GameStageLabel.text = lineGameStateLabel;
        CurrentPlayerColor = Color.red;

        SetGameFieldByDifficulty(GooglePlayAccount.Instance.Difficulty);
    }

    // Update is called once per frame
    public void Update()
    {
        Vector2 mousePos;
        if (IsLineGameState && CurrentPlayerLine == null && DialoguePanel.active == false)
        {
            if (Input.GetMouseButtonDown(0))
            {
                Vector3 closeToPoint = IsClickCloseToPoint();
                if (closeToPoint.z != -10000f)
                {
                    StartMousePos = closeToPoint;

                    InstantiatedLine = Instantiate(LineGenerator).GetComponent<LineRenderer>();
                    InstantiatedLine.transform.SetParent(ParentObject.transform);
                    InstantiatedLine.positionCount = 2;
                    InstantiatedLine.SetPosition(0, new Vector3(StartMousePos.x, StartMousePos.y, 0f));

                    InstantiatedLine.startColor = CurrentPlayerColor;
                    InstantiatedLine.endColor = CurrentPlayerColor;

                    FindAndChangePointColor(closeToPoint, InstantiatedLine.endColor);
                }
            }

            if (Input.GetMouseButton(0))
            {
                Vector3 closeToPoint = IsClickCloseToPoint();
                if (closeToPoint.z != -10000f && InstantiatedLine != null && !closeToPoint.Equals(StartMousePos))
                {
                    InstantiatedLine.SetPosition(1, new Vector3(closeToPoint.x, closeToPoint.y, 0f));
                    FindAndChangePointColor(closeToPoint, InstantiatedLine.startColor);
                    secondPointCandidate = closeToPoint;
                }
                else if (InstantiatedLine != null)
                {
                    if (secondPointCandidate.z != -10000f)
                    {
                        ReinstatePointColorToLast(InstantiatedLine.GetPosition(1));
                        secondPointCandidate = new Vector3(0f, 0f, -10000f);
                    }
                    mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
                    InstantiatedLine.SetPosition(1, new Vector3(mousePos.x, mousePos.y, 0f));
                }
            }

            if (Input.GetMouseButtonUp(0))
            {
                Vector3 closeToPoint = IsClickCloseToPoint();
                if (closeToPoint.z != -10000f && InstantiatedLine != null && !closeToPoint.Equals(StartMousePos))
                {
                    InstantiatedLine.SetPosition(1, new Vector3(closeToPoint.x, closeToPoint.y, 0f));
                    if (LineInList(AlreadyDrawnLineList, InstantiatedLine))
                    {
                        ReinstatePointColorToLast(InstantiatedLine.GetPosition(0));
                        ReinstatePointColorToLast(InstantiatedLine.GetPosition(1));
                        Destroy(InstantiatedLine.gameObject);
                    }
                    else
                    {
                        CurrentPlayerLine = InstantiatedLine;
                        SetCollider();
                        FindAndChangePointColor(closeToPoint, InstantiatedLine.startColor);
                    }
                    InstantiatedLine = null;
                }
                else if (InstantiatedLine != null)
                {
                    ReinstatePointColorToLast(InstantiatedLine.GetPosition(0));
                    ReinstatePointColorToLast(InstantiatedLine.GetPosition(1));
                    Destroy(InstantiatedLine.gameObject);
                    InstantiatedLine = null;
                }
            }
        }

        else if (!IsLineGameState && DialoguePanel.active == false)
        {
            if (Input.GetMouseButtonDown(0))
            {
                mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
                Vector2 mousePos2D = new Vector2(mousePos.x, mousePos.y);

                RaycastHit2D hit = Physics2D.Raycast(mousePos2D, Vector2.zero);
                if (hit.collider != null)
                {
                    if (!LineInList(SelectedLines, hit.collider.GetComponent<LineRenderer>()))
                    {
                        LineRenderer selectedLine = Instantiate(LineGenerator).GetComponent<LineRenderer>();
                        LineRenderer realLine = hit.collider.GetComponent<LineRenderer>();
                        
                        selectedLine.transform.SetParent(ParentObject.transform);
                        selectedLine.positionCount = 2;
                        selectedLine.SetPosition(0, realLine.GetPosition(0));
                        selectedLine.SetPosition(1, realLine.GetPosition(1));

                        SelectedLines.Add(selectedLine);

                        ColorLine(selectedLine, Color.green);
                    }
                }
            }
        }
    }

    public void DeleteLastLine()
    {
        if (IsLineGameState)
        {
            if (CurrentPlayerLine != null)
            {
                ReinstatePointColorToLast(CurrentPlayerLine.GetPosition(0));
                ReinstatePointColorToLast(CurrentPlayerLine.GetPosition(1));
                Destroy(CurrentPlayerLine.gameObject);
            }
            else
            {
                SSTools.ShowMessage("You didn't choose a line!", SSTools.Position.bottom, SSTools.Time.twoSecond);
            }
        }
        else if (!IsLineGameState)
        {
            if (SelectedLines.Count != 0)
            {
                LineRenderer selectedLine = SelectedLines[SelectedLines.Count - 1];
                ReinstatePointColorToLast(selectedLine.GetPosition(0));
                ReinstatePointColorToLast(selectedLine.GetPosition(1));
                Destroy(selectedLine.gameObject);
                SelectedLines.Remove(selectedLine);

                foreach (var line in SelectedLines)
                {
                    FindAndChangePointColor(line.GetPosition(0), Color.green);
                    FindAndChangePointColor(line.GetPosition(1), Color.green);
                }
            }
        }
    }

    public void SetGameState()
    {
        if (IsLineGameState && CurrentPlayerLine != null)
        {
            DisableAllButtons();
            GenericDialog dialog = GenericDialog.Instance();
            dialog.Message("Are you sure?");
            dialog.OnAccept(() => {
                AlreadyDrawnLineList.Add(CurrentPlayerLine);
                InstantiatedLine = null;
                IsLineGameState = !IsLineGameState;
                GameStageLabel.text = polygonCheckStageLabel;
                CheckPolygonButton.SetActive(true);
                EnableAllButtons();
                dialog.Hide();
            });

            dialog.OnDecline(() => {
                EnableAllButtons();
                dialog.Hide();
            });
            dialog.Show();
        }
        else if (CurrentPlayerLine != null)
        {
            DisableAllButtons();
            GenericDialog dialog = GenericDialog.Instance();
            dialog.Message("Are you sure?");
            dialog.OnAccept(() => {
                int listLenght = SelectedLines.Count;
                for (int i = 0; i < listLenght; i++)
                {
                    DeleteLastLine();
                }

                IsLineGameState = !IsLineGameState;
                CurrentPlayerLine = null;
                if (CurrentPlayerColor == Color.red)
                    CurrentPlayerColor = Color.blue;
                else
                    CurrentPlayerColor = Color.red;
                GameStageLabel.text = lineGameStateLabel;
                CheckPolygonButton.SetActive(false);
                EnableAllButtons();
                dialog.Hide();
            });

            dialog.OnDecline(() => {
                EnableAllButtons();
                dialog.Hide();
            });
            dialog.Show();
        }
        else
        {
            SSTools.ShowMessage("You didn't choose a line!", SSTools.Position.bottom, SSTools.Time.twoSecond);
        }
    }

    public void CheckIfPlayerGetsPoint()
    {
        if (SelectedLines.Count < 3)
        {
            ClearSelectedLines();
            SSTools.ShowMessage("You selected less than 3 lines!", SSTools.Position.bottom, SSTools.Time.twoSecond);
            return;
        }
        if (!LinesFormPolygon())
        {
            ClearSelectedLines();
            SSTools.ShowMessage("Not a polygon!", SSTools.Position.bottom, SSTools.Time.twoSecond);
            return;
        }
        if (PolygonAlreadyFound())
        {
            ClearSelectedLines();
            SSTools.ShowMessage("Polygon already found!", SSTools.Position.bottom, SSTools.Time.twoSecond);
            return;
        }
        if (!LineInList(SelectedLines, CurrentPlayerLine))
        {
            ClearSelectedLines();
            SSTools.ShowMessage("Polygon not created by you!", SSTools.Position.bottom, SSTools.Time.twoSecond);
            return;
        }

        SSTools.ShowMessage("You got " + SelectedLines.Count + " points!", SSTools.Position.bottom, SSTools.Time.twoSecond);

        List<LineRenderer> newList = new List<LineRenderer>();
        DeepCopyList(newList, SelectedLines);
        FoundPolygons.Add(newList);
        if (CurrentPlayerColor == Color.red)
        {
            int currentPlayerPoints = int.Parse(PlayerOnePoints.text) + SelectedLines.Count;
            PlayerOnePoints.text = (currentPlayerPoints).ToString();
            if (currentPlayerPoints >= 10)
            {
                SetDialogWindow("PlayerOne wins!");
            }
        }
        else
        {
            int currentPlayerPoints = int.Parse(PlayerTwoPoints.text) + SelectedLines.Count;
            PlayerTwoPoints.text = (currentPlayerPoints).ToString();
            if (currentPlayerPoints >= 10)
            {
                SetDialogWindow("PlayerTwo wins!");
            }
        }
        //SaveExpandedGameData();
        ColorBaseLineListPolygon(SelectedLines, CurrentPlayerColor);
        ClearSelectedLines();
    }

    public void OpenCloseSettings()
    {
        if (SettingsPanel.active)
        {
            SettingsPanel.SetActive(false);
            EnableAllButtons();
        }
        else
        {
            DisableAllButtons();
            SettingsPanel.SetActive(true);
        }
    }

    public void OnToTheMainManuClick()
    {
        DisableAllButtons();
        GenericDialog dialog = GenericDialog.Instance();
        dialog.Message("Are you sure?");
        dialog.OnAccept(() => {
            SceneManager.LoadScene("MainActivity");
            dialog.Hide();
        });

        dialog.OnDecline(() => {
            List<Button> foundBtns = new List<Button>(FindObjectsOfType<Button>());
            foreach (var button in foundBtns)
            {
                if (button.name == "QuitBtn")
                {
                    button.interactable = true;
                    break;
                }
            }
            dialog.Hide();
        });
        dialog.Show();
    }

    private void DisableAllButtons()
    {
        List<Button> foundBtns = new List<Button>(FindObjectsOfType<Button>());
        foreach (var button in foundBtns)
        {
            if (button.name != "SettingsBtn" && button.name != "DialogueBtn")
            {
                button.interactable = false;
            }
        }
    }

    private void EnableAllButtons()
    {
        List<Button> foundBtns = new List<Button>(FindObjectsOfType<Button>());
        foreach (var button in foundBtns)
        {
            button.interactable = true;
        }
    }

    private void SetDialogWindow(string message)
    {
        DialoguePanel.SetActive(true);
        DialogueText.text = message;
        DisableAllButtons();
        DialogueBtn.interactable = true;
    }

    private void ColorBaseLineListPolygon(List<LineRenderer> polygon, Color currentPlayerColor)
    {
        foreach (var baseLine in AlreadyDrawnLineList)
        {
            foreach (var line in polygon)
            {
                if(LinesAreEqual(baseLine, line))
                {
                    ColorLine(baseLine, currentPlayerColor);
                }
            }
        }
    }

    private bool LinesAreEqual(LineRenderer baseLine, LineRenderer line)
    {
        if(LineContainsPoint(baseLine.GetPosition(0), line) && LineContainsPoint(baseLine.GetPosition(1), line))
        {
            return true;
        }
        return false;
    }

    private void ColorLine(LineRenderer line, Color currentPlayerColor)
    {
        line.startColor = currentPlayerColor;
        line.endColor = currentPlayerColor;
        FindAndChangePointColor(line.GetPosition(0), currentPlayerColor);
        FindAndChangePointColor(line.GetPosition(1), currentPlayerColor);
    }

    private bool LinesFormPolygon()
    {
        foreach (var line in SelectedLines)
        {
            if (PointPresentInLineList(SelectedLines, line.GetPosition(0)) != 2
                || PointPresentInLineList(SelectedLines, line.GetPosition(1)) != 2)
            {
                return false;
            }
        }
        return true;
    }

    private int PointPresentInLineList(List<LineRenderer> list, Vector3 point)
    {
        int pointNumber = 0;
        foreach (var line in list)
        {
            if (LineContainsPoint(point, line))
            {
                pointNumber++;
            }
        }
        return pointNumber;
    }

    private void ClearSelectedLines()
    {
        int listLenght = SelectedLines.Count;
        for (int i = 0; i < listLenght; i++)
        {
            DeleteLastLine();
        }
        SelectedLines.Clear();
    }

    private void DeepCopyList(List<LineRenderer> listToCopyTo, List<LineRenderer> copiedList)
    {
        foreach (var line in copiedList)
        {
            LineRenderer copiedLine = Instantiate(LineGenerator).GetComponent<LineRenderer>();
            copiedLine.positionCount = 2;
            copiedLine.SetPosition(0, line.GetPosition(0));
            copiedLine.SetPosition(1, line.GetPosition(1));
            copiedLine.gameObject.SetActive(false);
            listToCopyTo.Add(copiedLine);
        }
    }

    private bool PolygonAlreadyFound()
    {
        foreach (var polygon in FoundPolygons)
        {
            if (ListEquals(polygon, SelectedLines))
            {
                return true;
            }
        }
        return false;
    }

    private bool ListEquals(List<LineRenderer> polygon, List<LineRenderer> selectedLines)
    {

        foreach (var line in selectedLines)
        {
            if (!LineInList(polygon, line))
            {
                return false;
            }
        }
        return true;
    }

    private bool LineInList(List<LineRenderer> list, LineRenderer line)
    {
        foreach (var lineInList in list)
        {
            if ((lineInList.GetPosition(0).Equals(line.GetPosition(0)) && lineInList.GetPosition(1).Equals(line.GetPosition(1)))
                || (lineInList.GetPosition(0).Equals(line.GetPosition(1)) && lineInList.GetPosition(1).Equals(line.GetPosition(0))))
            {
                return true;
            }
        }
        return false;
    }

    private bool FindAndChangePointColor(Vector3 other, Color color)
    {

        foreach (GameObject point in PointList)
        {
            if (PointsAreEqual(point.transform.position, Camera.main.WorldToScreenPoint(other)))
            {
                point.GetComponent<Image>().color = color;
                return true;
            }
        }
        return false;
    }

    private bool PointsAreEqual(Vector3 pointA, Vector3 pointB)
    {
        float pointFloatX = pointA.x;
        float otherFloatX = pointB.x;
        float differenceX = Math.Abs(pointFloatX * .0001f);

        float pointFloatY = pointA.y;
        float otherFloatY = pointB.y;
        float differenceY = Math.Abs(pointFloatY * .0001f);

        if (Math.Abs(pointFloatX - (float)otherFloatX) <= differenceX && Math.Abs(pointFloatY - (float)otherFloatY) <= differenceY)
        {
            return true;
        }
        return false;
    }

    private void ReinstatePointColorToLast(Vector3 point)
    {
        FindAndChangePointColor(point, Color.white);
        for (int i = AlreadyDrawnLineList.Count - 1; i >= 0; i--)
        {
            Color commonPointColor;
            if (LineContainsPoint(point, AlreadyDrawnLineList[i]))
                commonPointColor = AlreadyDrawnLineList[i].endColor;
            else
            {
                commonPointColor = Color.white;
            }
            if (commonPointColor != Color.white)
            {
                FindAndChangePointColor(point, commonPointColor);
                return;
            }
        }
    }

    private bool LineContainsPoint(Vector3 point, LineRenderer line)
    {
        if (PointsAreEqual(Camera.main.WorldToScreenPoint(line.GetPosition(0)), Camera.main.WorldToScreenPoint(point)) 
            || PointsAreEqual(Camera.main.WorldToScreenPoint(line.GetPosition(1)), Camera.main.WorldToScreenPoint(point)))
            return true;
        return false;
    }

    private Vector3 IsClickCloseToPoint()
    {
        foreach (var point in PointList)
        {
            Vector3 pointPos = point.transform.position;
            Vector3 mousePos = Input.mousePosition;
            if (mousePos.x > pointPos.x - 80 && mousePos.x < pointPos.x + 80 && mousePos.y > pointPos.y - 80 && mousePos.y < pointPos.y + 80)
            {
                return Camera.main.ScreenToWorldPoint(pointPos);
            }
        }
        return new Vector3(0f, 0f, -10000f);
    }

    private void SetCollider()
    {
        if (CurrentPlayerLine != null)
        {
            var startPos = CurrentPlayerLine.GetPosition(0);
            var endPos = CurrentPlayerLine.GetPosition(1);
            BoxCollider2D col = CurrentPlayerLine.GetComponent<BoxCollider2D>();
            float lineLength = Vector3.Distance(startPos, endPos);
            col.size = new Vector3(lineLength, 0.5f, 0.25f);
            Vector3 midPoint = (startPos + endPos) / 2;
            col.transform.position = midPoint;
            float angle = (Mathf.Abs(startPos.y - endPos.y) / Mathf.Abs(startPos.x - endPos.x));
            if ((startPos.y < endPos.y && startPos.x > endPos.x) || (endPos.y < startPos.y && endPos.x > startPos.x))
            {
                angle *= -1;
            }
            angle = Mathf.Rad2Deg * Mathf.Atan(angle);
            col.transform.Rotate(0, 0, angle);
        }
    }

    private void SetGameFieldByDifficulty(int diffic)
    {
        if (PointList == null)
        {
            switch (diffic)
            {
                case 0:
                    SetGameField(GetEasyPointPositions());
                    break;
                case 1:
                    SetGameField(GetNormalPointPositions());
                    break;
                case 2:
                    SetGameField(GetExpertPointPositions());
                    break;
                default:
                    SetGameField(GetEasyPointPositions());
                    break;
            }
        }
    }

    private void SetGameField(List<Vector3> pointPositions)
    {
        PointList = new List<GameObject>();
        foreach (Vector3 pointPos in pointPositions)
        {
            GameObject point = Instantiate(PointGenerator);
            NewPoint = point.GetComponent<Image>();
            NewPoint.transform.SetParent(ParentObject.transform);
            NewPoint.transform.localPosition = pointPos;
            NewPoint.gameObject.transform.SetSiblingIndex(0);
            PointList.Add(point);
        }
    }

    private List<Vector3> GetEasyPointPositions()
    {
        return new List<Vector3>
        {
            new Vector3(300f, 300f, 0f),
            new Vector3(-300f, 300f, 0f),
            new Vector3(300f, -300f, 0f),
            new Vector3(-300f, -300f, 0f)
        };
    }

    private List<Vector3> GetNormalPointPositions()
    {
        return new List<Vector3>
        {
            new Vector3(-400f, 200f, 0f),
            new Vector3(-400f, -200f, 0f),
            new Vector3(400f, 200f, 0f),
            new Vector3(400f, -200f, 0f),
            new Vector3(0f, 400f, 0f),
            new Vector3(0f, -400f, 0f)
        };
    }

    private List<Vector3> GetExpertPointPositions()
    {
        return new List<Vector3>
        {
            new Vector3(-400f, 200f, 0f),
            new Vector3(-400f, -200f, 0f),
            new Vector3(400f, 200f, 0f),
            new Vector3(400f, -200f, 0f),

            new Vector3(-200f, 400f, 0f),
            new Vector3(-200f, -400f, 0f),
            new Vector3(200f, 400f, 0f),
            new Vector3(200f, -400f, 0f),
        };
    }

}
