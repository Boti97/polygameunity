﻿using System;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using GooglePlayGames;
using GooglePlayGames.BasicApi;
using UnityEngine.SocialPlatforms;
using System.Threading.Tasks;
using System.Collections;
using Firebase.Auth;
using UnityEngine.SceneManagement;
using System.Collections.Generic;

public class MainScreenBehaviour : MonoBehaviour
{

    [SerializeField]
    private GameObject dialoguePanel;

    [SerializeField]
    private GameObject dropdownMenu;

    [SerializeField]
    private TextMeshProUGUI signInOutBtnLabel;

    public GameObject DialoguePanel { get => dialoguePanel; set => dialoguePanel = value; }
    public GameObject DropdownMenu { get => dropdownMenu; set => dropdownMenu = value; }

    private void Start()
    {
        DialoguePanel.SetActive(false);
        if (GooglePlayAccount.Instance.FirebaseUser == null)
        {
            UnityMainThreadDispatcher.Instance().Enqueue(GooglePlayAccount.Instance.SignIn(SetPlayerName));
        }
        else
        {
            SetPlayerName(GooglePlayAccount.Instance.FirebaseUser.DisplayName);
        }
        DropdownChange(0);
    }

    public void PlayQuickMatch()
    {
        if(GooglePlayAccount.Instance.FirebaseUser == null)
        {
            SSTools.ShowMessage("You have to sign in!", SSTools.Position.bottom, SSTools.Time.twoSecond);
        }
        else
        {
            GooglePlayAccount.Instance.FromMatches = false;
            SceneManager.LoadScene("OnlineActivity");
        }
    }

    //TEST
    public void OpenMatchesWindow()
    {
        if (GooglePlayAccount.Instance.FirebaseUser == null)
        {
            SSTools.ShowMessage("You have to sign in!", SSTools.Position.bottom, SSTools.Time.twoSecond);
        }
        else
        {
            SceneManager.LoadScene("MatchesActivity");
        }
        //SceneManager.LoadScene("MatchesActivity");
    }

    public void SetPlayerName(string playerName)
    {
        TextMeshProUGUI UserNameText;
        GameObject gameObject;
        gameObject = GameObject.Find("UsernameText");
        UserNameText = gameObject.GetComponent<TextMeshProUGUI>() as TextMeshProUGUI;
        if (UserNameText != null)
        {
            UserNameText.text = playerName;
            signInOutBtnLabel.text = "Sign out";
        }
        else
            signInOutBtnLabel.text = "Sign in";

    }

    public void SetPlayerImage(String imageUri)
    {
        StartCoroutine(SetImage(imageUri));
    }

    IEnumerator SetImage(string url)
    {
        Image profilePicture;
        GameObject gameObject;
        gameObject = GameObject.Find("ProfilePicture");
        profilePicture = gameObject.GetComponent<Image>() as Image;
        WWW www = new WWW(url);
        yield return www;
        profilePicture.sprite = Sprite.Create(www.texture, new Rect(0, 0, www.texture.width, www.texture.height), new Vector2(0, 0));
    }

    public void OpenCloseSettings()
    {
        if (DialoguePanel.active)
        {
            DialoguePanel.SetActive(false);
            DropdownMenu.SetActive(true);
            EnableAllButtons();
        }
        else
        {
            DisableAllButtons();
            DialoguePanel.SetActive(true);
            DropdownMenu.SetActive(false);
        }
    }

    public void CloseSettings()
    {
        EnableAllButtons();
        DialoguePanel.SetActive(false);
    }

    public void SignInOut()
    {
        if (signInOutBtnLabel.text == "Sign out")
        {
            GooglePlayAccount.Instance.SignOut();
            SetPlayerName("Unknown");
            signInOutBtnLabel.text = "Sign in";
        }
        else
        {
            UnityMainThreadDispatcher.Instance().Enqueue(GooglePlayAccount.Instance.SignIn(SetPlayerName));
        }
        
    }

    public void DropdownChange(int index)
    {
        GooglePlayAccount.Instance.Difficulty = index;
    }

    private void DisableAllButtons()
    {
        List<Button> foundBtns = new List<Button>(FindObjectsOfType<Button>());
        foreach (var button in foundBtns)
        {
            if (button.name != "SettingsBtn")
            {
                button.interactable = false;
            }
        }
    }

    private void EnableAllButtons()
    {
        List<Button> foundBtns = new List<Button>(FindObjectsOfType<Button>());
        foreach (var button in foundBtns)
        {
            button.interactable = true;
        }
    }

}
