﻿using Firebase.Auth;
using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MatchesActivityBehaviour : MonoBehaviour
{
    private FirebaseBehaviour firebaseBehaviour;
    private FirebaseUser firebaseUser;

    public ScrollRect scrollView;
    public GameObject scrollContent;
    public GameObject scrollItemPrefab;
    public GameObject settingsPanel;
    private List<string> roomIds;

    public GameObject SettingsPanel { get => settingsPanel; set => settingsPanel = value; }
    public FirebaseBehaviour FirebaseBehaviour { get => firebaseBehaviour; set => firebaseBehaviour = value; }
    public FirebaseUser FirebaseUser { get => firebaseUser; set => firebaseUser = value; }
    public List<string> RoomIds { get => roomIds; set => roomIds = value; }

    //TEST
    void Start()
    {
        RoomIds = new List<string>();
        SettingsPanel.SetActive(false);
        FirebaseBehaviour = new FirebaseBehaviour(this);
        FirebaseUser = GooglePlayAccount.Instance.FirebaseUser;
        FirebaseBehaviour.GetPlayerRooms(FirebaseUser.UserId);
    }
    public void OpenCloseSettings()
    {
        if (SettingsPanel.active)
        {
            SettingsPanel.SetActive(false);
            EnableAllButtons();
        }
        else
        {
            DisableAllButtons();
            SettingsPanel.SetActive(true);
        }
    }

    public IEnumerator SetRoomList(List<string> rooms)
    {

        for (int i = 0; i < rooms.Count; i++)
        {
            string[] nameAndId = rooms[i].Split(':');
            RoomIds.Add(nameAndId[1]);
            generateItem(i + ": vs " + nameAndId[0]);
        }
        yield return null;
    }

    public void generateItem(string itemText)
    {
        Button scrollItemBtn = Instantiate(scrollItemPrefab).GetComponent<Button>();
        TextMeshProUGUI text = scrollItemBtn.transform.Find("ScrollItemBtnText").gameObject.GetComponent<TextMeshProUGUI>();
        scrollItemBtn.onClick.AddListener(delegate { OnScrollItemClick(GetIndex(text.text)); });
        scrollItemBtn.transform.SetParent(scrollContent.transform, false);
        text.text = itemText;
    }

    private int GetIndex(string text)
    {
        string[] splittedText = text.Split(":"[0]);
        return Int32.Parse(splittedText[0]);
    }

    public void OnScrollItemClick(int index)
    {
        GooglePlayAccount.Instance.FromMatches = true;
        GooglePlayAccount.Instance.RoomIdFromMatches = RoomIds[index];
        SceneManager.LoadScene("OnlineActivity");
    }

    public void OnToTheMainManuClick()
    {
        SceneManager.LoadScene("MainActivity");
    }

    private void DisableAllButtons()
    {
        List<Button> foundBtns = new List<Button>(FindObjectsOfType<Button>());
        foreach (var button in foundBtns)
        {
            if (button.name != "SettingsBtn")
            {
                button.interactable = false;
            }
        }
    }

    private void EnableAllButtons()
    {
        List<Button> foundBtns = new List<Button>(FindObjectsOfType<Button>());
        foreach (var button in foundBtns)
        {
            button.interactable = true;
        }
    }
}
