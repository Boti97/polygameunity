﻿using Firebase.Auth;
using GooglePlayGames;
using GooglePlayGames.BasicApi;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine;

public class GooglePlayAccount : MonoBehaviour
{
    private String authCode;
    private static GooglePlayAccount _instance;
    private FirebaseUser firebaseUser;
    private FirebaseAuth auth;
    private int difficulty;
    private bool fromMatches;
    private string roomIdFromMatches;

    public static GooglePlayAccount Instance
    {
        get
        {
            if (_instance == null)
            {
                _instance = GameObject.FindObjectOfType<GooglePlayAccount>();

            }

            return _instance;
        }
    }

    public string AuthCode { get => authCode; set => authCode = value; }
    public FirebaseUser FirebaseUser { get => firebaseUser; set => firebaseUser = value; }
    public FirebaseAuth Auth { get => auth; set => auth = value; }
    public int Difficulty { get => difficulty; set => difficulty = value; }
    public bool FromMatches { get => fromMatches; set => fromMatches = value; }
    public string RoomIdFromMatches { get => roomIdFromMatches; set => roomIdFromMatches = value; }

    public void Awake()
    {
        if (_instance != null && _instance != this)
        {
            Destroy(this.gameObject);
        }
        else
        {
            DontDestroyOnLoad(gameObject);
        }
    }

    public IEnumerator SignIn(Action<string> action)
    {
        PlayGamesClientConfiguration config = new PlayGamesClientConfiguration.Builder()
                    .RequestServerAuthCode(false /* Don't force refresh */)
                    .Build();

        PlayGamesPlatform.InitializeInstance(config);
        PlayGamesPlatform.Activate();
        Social.localUser.Authenticate((bool success) =>
        {
            if (success)
            {
                AuthCode = PlayGamesPlatform.Instance.GetServerAuthCode();

                Auth = Firebase.Auth.FirebaseAuth.DefaultInstance;
                Credential credential = PlayGamesAuthProvider.GetCredential(AuthCode);
                Auth.SignInWithCredentialAsync(credential).ContinueWith(task =>
                {
                    if (task.IsCanceled)
                    {
                        SSTools.ShowMessage("Task cancelled!", SSTools.Position.bottom, SSTools.Time.twoSecond);
                        Debug.LogError("SignInWithCredentialAsync was canceled.");
                    }
                    if (task.IsFaulted)
                    {
                        SSTools.ShowMessage("Task faulted!", SSTools.Position.bottom, SSTools.Time.twoSecond);
                        Debug.LogError("SignInWithCredentialAsync encountered an error: " + task.Exception);
                    }
                    FirebaseUser = task.Result;
                    action(FirebaseUser.DisplayName);
                }, TaskScheduler.FromCurrentSynchronizationContext());
            }
        });
        yield return null;
    }

    public void SignOut()
    {
        Auth.SignOut();
        FirebaseUser = null;
    }
}
