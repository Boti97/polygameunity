﻿using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

[RequireComponent(typeof(CanvasGroup))]
public class GenericDialog : MonoBehaviour
{
    [SerializeField]
    public GameObject yesNoDialog;
    [SerializeField]
    public TextMeshProUGUI message;
    [SerializeField]
    public Button acceptButton, declineButton;

    private CanvasGroup cg;

    void Awake()
    {
        cg = GetComponent<CanvasGroup>();
    }

    private void Start()
    {
        yesNoDialog.SetActive(false);
    }

    public GenericDialog OnAccept(UnityAction action)
    {
        acceptButton.onClick.RemoveAllListeners();
        acceptButton.onClick.AddListener(action);
        return this;
    }

    public GenericDialog OnDecline(UnityAction action)
    {
        declineButton.onClick.RemoveAllListeners();
        declineButton.onClick.AddListener(action);
        return this;
    }

    public GenericDialog Message(string message)
    {
        this.message.text = message;
        return this;
    }

    // show the dialog, set it's canvasGroup.alpha to 1f or tween like here
    public void Show()
    {
        yesNoDialog.SetActive(true);
        acceptButton.gameObject.SetActive(true);
        declineButton.gameObject.SetActive(true);
        this.transform.SetAsLastSibling();
        cg.interactable = true;
        cg.alpha = 1f;
        cg.blocksRaycasts = true;
    }

    public void Hide()
    {
        yesNoDialog.SetActive(false);
        acceptButton.gameObject.SetActive(false);
        declineButton.gameObject.SetActive(false);
        cg.interactable = false;
        cg.alpha = 0f;
    }

    private static GenericDialog instance;
    public static GenericDialog Instance()
    {
        if (!instance)
        {
            instance = FindObjectOfType(typeof(GenericDialog)) as GenericDialog;
            if (!instance)
                Debug.Log("There need to be at least one active GenericDialog on the scene");
        }

        return instance;
    }

}
