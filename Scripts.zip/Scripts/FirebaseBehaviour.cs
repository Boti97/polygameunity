﻿using Firebase;
using Firebase.Database;
using Firebase.Unity.Editor;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FirebaseBehaviour
{
    DatabaseReference reference;
    OnlineGameBehaviour onlineGameBehaviour;
    MatchesActivityBehaviour matchesActivityBehaviour;

    public DatabaseReference Reference { get => reference; set => reference = value; }
    public OnlineGameBehaviour OnlineGameBehaviour { get => onlineGameBehaviour; set => onlineGameBehaviour = value; }
    public MatchesActivityBehaviour MatchesActivityBehaviour { get => matchesActivityBehaviour; set => matchesActivityBehaviour = value; }

    public FirebaseBehaviour(OnlineGameBehaviour onlineBehav)
    {
        // Set this before calling into the realtime database.
        FirebaseApp.DefaultInstance.SetEditorDatabaseUrl("https://polygameunity.firebaseio.com/");

        // Get the root reference location of the database.
        Reference = FirebaseDatabase.DefaultInstance.RootReference;

        OnlineGameBehaviour = onlineBehav;
    }

    public FirebaseBehaviour(MatchesActivityBehaviour matchesActivityBehaviour)
    {
        // Set this before calling into the realtime database.
        FirebaseApp.DefaultInstance.SetEditorDatabaseUrl("https://polygameunity.firebaseio.com/");

        // Get the root reference location of the database.
        Reference = FirebaseDatabase.DefaultInstance.RootReference;

        MatchesActivityBehaviour = matchesActivityBehaviour;
    }

    public void WriteNewUser(string name, string userId)
    {
        User user = new User(name);
        string json = JsonUtility.ToJson(user);

        FirebaseDatabase.DefaultInstance.GetReference("users/" + userId).GetValueAsync().ContinueWith(task => {
            if (task.IsFaulted)
            {
                Reference.Child("users").Child(userId).SetRawJsonValueAsync(json);
            }
            DataSnapshot dataSnapshot = task.Result;
            if (dataSnapshot.Value == null)
            {
                Reference.Child("users").Child(userId).SetRawJsonValueAsync(json);
            }
        });
    }

    public string OpenNewRoom(string userId, string name, string state, int diffic)
    {
        string roomId = Reference.Child("rooms").Push().Key;

        Room room = new Room(name, "Unknown", userId, "Unknown", state, userId, diffic);
        OpenRoom openRoom = new OpenRoom(roomId, diffic, userId);
        string roomJson = JsonUtility.ToJson(room);
        string openRoomJson = JsonUtility.ToJson(openRoom);

        Reference.Child("rooms").Child(roomId).SetRawJsonValueAsync(roomJson);
        Reference.Child("openRooms").Child(roomId).SetRawJsonValueAsync(openRoomJson);
        Reference.Child("users").Child(userId).Child("rooms").Child(roomId).SetRawJsonValueAsync(roomId);

        return roomId;
    }

    public void JoinToRoom(string roomId, string name, string playerId)
    {
        Reference.Child("rooms").Child(roomId).Child("playerTwoId").SetValueAsync(playerId);
        Reference.Child("rooms").Child(roomId).Child("playerTwoName").SetValueAsync(name);
        Reference.Child("users").Child(playerId).Child("rooms").Child(roomId).SetRawJsonValueAsync(roomId);
    }

    public void SetRoomOpponentInUserRoom(string playerId, string roomId, string opponentName)
    {
        Reference.Child("users").Child(playerId).Child("rooms").Child(roomId).SetValueAsync(opponentName);
    }

    public void FindRoom(string userId, string name, int diffic)
    {
        string roomId = null;
        FirebaseDatabase.DefaultInstance.GetReference("openRooms").GetValueAsync().ContinueWith(task => {
            if (task.IsFaulted)
            {
                Debug.LogError("Task faulted");
            }
            else if (task.IsCompleted)
            {
                DataSnapshot roomSnap = task.Result;

                foreach (DataSnapshot room in roomSnap.Children)
                {
                    if (room.Child("difficulty").Value.ToString().Equals(diffic.ToString()) && !room.Child("openUserId").Value.ToString().Equals(userId))
                    {
                        //találtunk egy nyitott szobát a megfelelő nehézségi szinten
                        roomId = (string)room.Child("openRoomId").Value;
                        //csatlakozzunk hozzá
                        JoinToRoom(roomId, name, userId);
                        //vegyük ki ezt a nyitott szobák közül
                        CloseOpenRoom(roomId);
                    }
                }
                if(roomId == null)
                {
                    //nem találtunk megfelelő nyitott szobát
                    //nyissunk egyet
                    roomId = OpenNewRoom(userId, name, null, diffic);
                }

                //szóljunk, hogy találtunk szobát
                OnlineGameBehaviour.SetRoom(roomId);

                //feliratkozunk a szoba eseményeire
                SubscribeToRoomState(roomId);
            }
        });
    }
    
    public void GetRoom(string roomId)
    {
        Room room = null;
        FirebaseDatabase.DefaultInstance.GetReference("rooms/" + roomId).GetValueAsync().ContinueWith(task => {
            if (task.IsFaulted)
            {
                Debug.LogError("GetRoom task faulted");
            }
            else if (task.IsCompleted)
            {
                DataSnapshot roomSnap = task.Result;
                room = new Room(roomSnap.Child("playerOneName").Value.ToString(),
                roomSnap.Child("playerTwoName").Value.ToString(),
                roomSnap.Child("playerOneId").Value.ToString(),
                roomSnap.Child("playerTwoId").Value.ToString(),
                roomSnap.Child("gameState").Value.ToString(),
                roomSnap.Child("currentPlayerId").Value.ToString(),
                Int32.Parse(roomSnap.Child("difficulty").Value.ToString()));

                OnlineGameBehaviour.SetRoomObjectAndNames(room);
            }
        });
    }

    public void ChangeRoomGameState(string roomId, string gameState)
    {
        Reference.Child("rooms").Child(roomId).Child("gameState").SetValueAsync(gameState);
    }

    public void ChangeRoomCurrentPlayer(string roomId, string currentPlayerId)
    {
        Reference.Child("rooms").Child(roomId).Child("currentPlayerId").SetValueAsync(currentPlayerId);
    }

    public void ChangeRoomPoints(string roomId, int onePoint, int twoPoint)
    {
        Reference.Child("rooms").Child(roomId).Child("playerOnePoint").SetValueAsync(onePoint);
        Reference.Child("rooms").Child(roomId).Child("playerTwoPoint").SetValueAsync(twoPoint);
    }

    public void CloseOpenRoom(string roomId)
    {
        Reference.Child("openRooms").Child(roomId).RemoveValueAsync();
    }

    public void RemoveRoom(string roomId, string playerId, string opponentId)
    {
        Reference.Child("rooms").Child(roomId).RemoveValueAsync();
        Reference.Child("users").Child(playerId).Child("rooms").Child(roomId).RemoveValueAsync();
        Reference.Child("users").Child(opponentId).Child("rooms").Child(roomId).RemoveValueAsync();
        Reference.Child("openRooms").Child(roomId).RemoveValueAsync();
        Reference.Child("expandedRoomDatas").Child(roomId).RemoveValueAsync();
    }

    public void GetRoomWithExpandedData(string roomId)
    {
        FirebaseDatabase.DefaultInstance.GetReference("expandedRoomDatas/" + roomId).GetValueAsync().ContinueWith(res => {
            if (res.IsFaulted)
            {
                Debug.LogError("GetRoom task faulted");
            }
            else if (res.IsCompleted)
            {
                List<Line> lines = new List<Line>();
                foreach (DataSnapshot lineDS in res.Result.Child("drawLines").Children)
                {
                    Line line = new Line(float.Parse(lineDS.Child("pointAX").Value.ToString()),
                        float.Parse(lineDS.Child("pointAY").Value.ToString()),
                        float.Parse(lineDS.Child("pointBX").Value.ToString()),
                        float.Parse(lineDS.Child("pointBY").Value.ToString()),
                        Int32.Parse(lineDS.Child("color").Value.ToString()));
                    lines.Add(line);
                }
                OnlineGameBehaviour.SetRoomFromExpandedData(lines,
                    Int32.Parse(res.Result.Child("playerOnePoint").Value.ToString()),
                    Int32.Parse(res.Result.Child("playerTwoPoint").Value.ToString()),
                    Int32.Parse(res.Result.Child("gameStage").Value.ToString()));
            }
        });
    }

    public void SubscribeToRoomState(string roomId)
    {
        Reference.Child("rooms").Child(roomId).Child("gameState").ValueChanged += GameStateChanged;
        Reference.Child("rooms").Child(roomId).Child("playerOnePoint").ValueChanged += PlayerOnePointChanged;
        Reference.Child("rooms").Child(roomId).Child("playerTwoPoint").ValueChanged += PlayerTwoPointChanged;
        Reference.Child("rooms").Child(roomId).ChildRemoved += RoomRemoved;
        Reference.Child("rooms").Child(roomId).Child("currentPlayerId").ValueChanged += PlayerChanged;
        Reference.Child("rooms").Child(roomId).Child("playerTwoName").ValueChanged += PlayerTwoNameChanged;
        Reference.Child("rooms").Child(roomId).Child("playerTwoId").ValueChanged += PlayerTwoIdChanged;
    }

    public void UnSubscribeToRoomState(string roomId)
    {
        Reference.Child("rooms").Child(roomId).Child("gameState").ValueChanged -= GameStateChanged;
        Reference.Child("rooms").Child(roomId).Child("playerOnePoint").ValueChanged -= PlayerOnePointChanged;
        Reference.Child("rooms").Child(roomId).Child("playerTwoPoint").ValueChanged -= PlayerTwoPointChanged;
        Reference.Child("rooms").Child(roomId).ChildRemoved -= RoomRemoved;
        Reference.Child("rooms").Child(roomId).Child("currentPlayerId").ValueChanged -= PlayerChanged;
        Reference.Child("rooms").Child(roomId).Child("playerTwoName").ValueChanged -= PlayerTwoNameChanged;
        Reference.Child("rooms").Child(roomId).Child("playerTwoId").ValueChanged -= PlayerTwoIdChanged;
    }

    public void GetPlayerRooms(string playerId)
    {
        FirebaseDatabase.DefaultInstance.GetReference("users/" + playerId +"/rooms").GetValueAsync().ContinueWith(task =>
        {
            if (task.IsFaulted)
            {
                Debug.LogError("GetRoom task faulted");
            }
            else if (task.IsCompleted)
            {
                DataSnapshot roomSnap = task.Result;
                List<string> rooms = new List<string>();
                foreach (DataSnapshot room in roomSnap.Children)
                {
                    string fullStr = room.Value + ":" + room.Key;
                    rooms.Add(fullStr);
                }
                UnityMainThreadDispatcher.Instance().Enqueue(MatchesActivityBehaviour.SetRoomList(rooms));
            }
        });
    }

    public void SaveExpandedGameDataToFireBase(string roomId, string expandedGameDataJson)
    {
        Reference.Child("expandedRoomDatas").Child(roomId).SetRawJsonValueAsync(expandedGameDataJson);
    }

    private void PlayerOnePointChanged(object sender, ValueChangedEventArgs args)
    {
        if (args.DatabaseError != null)
        {
            Debug.LogError(args.DatabaseError.Message);
            return;
        }
        if(args.Snapshot.Value != null)
        {
            OnlineGameBehaviour.PlayerOnePointChanged(Int32.Parse(args.Snapshot.Value.ToString()));
        }
    }

    private void PlayerTwoPointChanged(object sender, ValueChangedEventArgs args)
    {
        if (args.DatabaseError != null)
        {
            Debug.LogError(args.DatabaseError.Message);
            return;
        }
        if (args.Snapshot.Value != null)
        {
            OnlineGameBehaviour.PlayerTwoPointChanged(Int32.Parse(args.Snapshot.Value.ToString()));
        }
    }

    private void PlayerTwoNameChanged(object sender, ValueChangedEventArgs args)
    {
        if (args.DatabaseError != null)
        {
            Debug.LogError(args.DatabaseError.Message);
            return;
        }
        if (args.Snapshot.Value != null)
        {
            OnlineGameBehaviour.SetPlayerTwoName(args.Snapshot.Value.ToString());
        }
    }

    private void PlayerTwoIdChanged(object sender, ValueChangedEventArgs args)
    {
        if (args.DatabaseError != null)
        {
            Debug.LogError(args.DatabaseError.Message);
            return;
        }
        if (args.Snapshot.Value != null)
        {
            OnlineGameBehaviour.CurrentRoom.playerTwoId = args.Snapshot.Value.ToString();
            OnlineGameBehaviour.SetPlayerColorAndOpponentId();
        }
    }

    private void GameStateChanged(object sender, ValueChangedEventArgs args)
    {
        if (args.DatabaseError != null)
        {
            Debug.LogError(args.DatabaseError.Message);
            return;
        }
        if (args.Snapshot.Value != null)
        {
            UnityMainThreadDispatcher.Instance().Enqueue(OnlineGameBehaviour.SetRoomGameState(args.Snapshot.Value.ToString()));
        }
    }

    private void PlayerChanged(object sender, ValueChangedEventArgs args)
    {
        if (args.DatabaseError != null)
        {
            Debug.LogError(args.DatabaseError.Message);
            return;
        }
        if (args.Snapshot.Value != null)
        {
            UnityMainThreadDispatcher.Instance().Enqueue(OnlineGameBehaviour.PlayerChanged(args.Snapshot.Value.ToString()));
        }
    }

    private void RoomRemoved(object sender, ChildChangedEventArgs args)
    {
        if (args.DatabaseError != null)
        {
            Debug.LogError(args.DatabaseError.Message);
            return;
        }
        if (args.Snapshot.Value != null)
        {
            OnlineGameBehaviour.OpponentConceded();
        }
    }
}

[System.Serializable]
class ExpandedGameData
{
    [SerializeField]
    public List<Line> drawLines;
    [SerializeField]
    public int playerOnePoint;
    [SerializeField]
    public int playerTwoPoint;
    [SerializeField]
    public int gameStage;

    public ExpandedGameData()
    {
    }

    public ExpandedGameData(List<Line> drawLines, int playerOnePoint, int playerTwoPoint, int gameStage)
    {
        this.drawLines = drawLines;
        this.playerOnePoint = playerOnePoint;
        this.playerTwoPoint = playerTwoPoint;
        this.gameStage = gameStage;
    }
}

public class User
{
    public string username;
    public List<string> rooms;

    public User() { }

    public User(string username)
    {
        this.username = username;
        this.rooms = new List<string>();
    }
}

public class OpenRoom
{
    public string openRoomId;
    public int difficulty;
    public string openUserId;

    public OpenRoom() { }

    public OpenRoom(string roomId, int diffic, string userId)
    {
        this.openRoomId = roomId;
        this.difficulty = diffic;
        this.openUserId = userId;
    }
}

public class Room
{
    public string playerOneName;
    public string playerTwoName;
    public string playerOneId;
    public string playerTwoId;
    public string gameState;
    public string currentPlayerId;
    public int difficulty;

    public Room() {}

    public Room(string playerOneName, string playerTwoName, string playerOneId, string playerTwoId, 
        string gameState, string currentPlayerId, int difficulty)
    {
        this.playerOneName = playerOneName;
        this.playerTwoName = playerTwoName;
        this.playerOneId = playerOneId;
        this.playerTwoId = playerTwoId;
        this.gameState = gameState;
        this.currentPlayerId = currentPlayerId;
        this.difficulty = difficulty;
    }
}