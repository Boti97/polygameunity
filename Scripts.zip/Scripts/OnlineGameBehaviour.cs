﻿using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SocialPlatforms;
using UnityEngine.SceneManagement;
using System.Net;
using System.IO;
using Firebase.Auth;

public class OnlineGameBehaviour : MonoBehaviour
{
    private Vector3 startMousePos;
    private LineRenderer instantiatedLine;
    private List<GameObject> pointList;
    private List<LineRenderer> alreadyDrawnLineList;
    private Color currentPlayerColor;
    private LineRenderer currentPlayerLine;
    private bool isLineGameState;
    private Image newPoint;
    private List<List<LineRenderer>> foundPolygons;
    private List<LineRenderer> currentlyFoundPolygon;
    private Vector3 secondPointCandidate = new Vector3(0f, 0f, -10000f);
    private List<LineRenderer> selectedLines;
    private bool isThisPlayersTurn;
    private Animator loadAnimation;
    private FirebaseBehaviour firebaseBehaviour;
    private string roomId;
    private FirebaseUser firebaseUser;
    private Room currentRoom;
    private string currentPlayerId;
    private string opponentId;
    private bool conceded = false;
    private bool fromMatches = false;

    private readonly string lineGameStateLabel = "Choose a line!";
    private readonly string polygonCheckStageLabel = "Choose polygons!";
    private readonly string opponentChoosingLineLabel = "Wait for opponent!";

    [SerializeField]
    private GameObject parentObject;

    [SerializeField]
    private GameObject pointGenerator;

    [SerializeField]
    private GameObject lineGenerator;

    [SerializeField]
    private TextMeshProUGUI playerOnePoints;

    [SerializeField]
    private TextMeshProUGUI playerTwoPoints;

    [SerializeField]
    private TextMeshProUGUI gameStageLabel;

    [SerializeField]
    private GameObject checkPolygonButton;

    [SerializeField]
    private GameObject dialoguePanel;

    [SerializeField]
    private Button dialogueBtn;

    [SerializeField]
    private TextMeshProUGUI dialogueText;

    [SerializeField]
    private TextMeshProUGUI playerOneName;

    [SerializeField]
    private TextMeshProUGUI playerTwoName;

    [SerializeField]
    private GameObject settingsPanel;

    public Vector3 StartMousePos { get => startMousePos; set => startMousePos = value; }
    public LineRenderer InstantiatedLine { get => instantiatedLine; set => instantiatedLine = value; }
    public List<GameObject> PointList { get => pointList; set => pointList = value; }
    public List<LineRenderer> AlreadyDrawnLineList { get => alreadyDrawnLineList; set => alreadyDrawnLineList = value; }
    public LineRenderer CurrentPlayerLine { get => currentPlayerLine; set => currentPlayerLine = value; }
    public bool IsLineGameState { get => isLineGameState; set => isLineGameState = value; }
    public Image NewPoint { get => newPoint; set => newPoint = value; }
    public List<List<LineRenderer>> FoundPolygons { get => foundPolygons; set => foundPolygons = value; }
    public List<LineRenderer> SelectedLines { get => selectedLines; set => selectedLines = value; }
    public bool IsThisPlayersTurn { get => isThisPlayersTurn; set => isThisPlayersTurn = value; }
    public Animator LoadAnimation { get => loadAnimation; set => loadAnimation = value; }
    public FirebaseBehaviour FirebaseBehaviour { get => firebaseBehaviour; set => firebaseBehaviour = value; }
    public FirebaseUser FirebaseUser { get => firebaseUser; set => firebaseUser = value; }
    public GameObject ParentObject { get => parentObject; set => parentObject = value; }
    public GameObject PointGenerator { get => pointGenerator; set => pointGenerator = value; }
    public GameObject LineGenerator { get => lineGenerator; set => lineGenerator = value; }
    public TextMeshProUGUI PlayerOnePoints { get => playerOnePoints; set => playerOnePoints = value; }
    public TextMeshProUGUI PlayerTwoPoints { get => playerTwoPoints; set => playerTwoPoints = value; }
    public TextMeshProUGUI GameStageLabel { get => gameStageLabel; set => gameStageLabel = value; }
    public GameObject CheckPolygonButton { get => checkPolygonButton; set => checkPolygonButton = value; }
    public GameObject DialoguePanel { get => dialoguePanel; set => dialoguePanel = value; }
    public Button DialogueBtn { get => dialogueBtn; set => dialogueBtn = value; }
    public TextMeshProUGUI DialogueText { get => dialogueText; set => dialogueText = value; }
    public TextMeshProUGUI PlayerOneName { get => playerOneName; set => playerOneName = value; }
    public TextMeshProUGUI PlayerTwoName { get => playerTwoName; set => playerTwoName = value; }
    public string RoomId { get => roomId; set => roomId = value; }
    public Room CurrentRoom { get => currentRoom; set => currentRoom = value; }
    public string CurrentPlayerId { get => currentPlayerId; set => currentPlayerId = value; }
    public string OpponentId { get => opponentId; set => opponentId = value; }
    public Color CurrentPlayerColor { get => currentPlayerColor; set => currentPlayerColor = value; }
    public List<LineRenderer> CurrentlyFoundPolygon { get => currentlyFoundPolygon; set => currentlyFoundPolygon = value; }
    public GameObject SettingsPanel { get => settingsPanel; set => settingsPanel = value; }

    public void Start()
    {
        conceded = false;
        CheckPolygonButton.SetActive(false);
        SettingsPanel.SetActive(false);
        DialoguePanel.SetActive(false);

        FoundPolygons = new List<List<LineRenderer>>();
        CurrentlyFoundPolygon = new List<LineRenderer>();
        AlreadyDrawnLineList = new List<LineRenderer>();
        SelectedLines = new List<LineRenderer>();
        FirebaseBehaviour = new FirebaseBehaviour(this);

        LoadAnimation = GameObject.Find("loadAnim").GetComponent<Animator>();
        LoadAnimation.enabled = false;

        FirebaseUser = GooglePlayAccount.Instance.FirebaseUser;

        //ha a matches menüből jöttünk, akkor nem akarjuk máshogy építjük fel a pályát
        if (!GooglePlayAccount.Instance.FromMatches)
        {
            SetMultiplayerRoom();
        }
        else
        {
            fromMatches = true;
            //visszaállítjuk, mert a deafault, hogy quick matchből jönnek
            GooglePlayAccount.Instance.FromMatches = false;
            if (GooglePlayAccount.Instance.RoomIdFromMatches != null)
            {
                RoomId = GooglePlayAccount.Instance.RoomIdFromMatches;
                FirebaseBehaviour.GetRoom(RoomId);
                FirebaseBehaviour.GetRoomWithExpandedData(RoomId);
                FirebaseBehaviour.SubscribeToRoomState(RoomId);
            }
        }
    }

    public void Update()
    {
        Vector2 mousePos;
        if (IsLineGameState && CurrentPlayerLine == null && !DialoguePanel.active && IsThisPlayersTurn && !SettingsPanel.active)
        {
            if (Input.GetMouseButtonDown(0))
            {
                Vector3 closeToPoint = IsClickCloseToPoint();
                if (closeToPoint.z != -10000f)
                {
                    StartMousePos = closeToPoint;

                    InstantiatedLine = Instantiate(LineGenerator).GetComponent<LineRenderer>();
                    InstantiatedLine.transform.SetParent(ParentObject.transform);
                    InstantiatedLine.transform.SetSiblingIndex(0);
                    InstantiatedLine.positionCount = 2;
                    InstantiatedLine.SetPosition(0, new Vector3(StartMousePos.x, StartMousePos.y, 0f));

                    InstantiatedLine.startColor = CurrentPlayerColor;
                    InstantiatedLine.endColor = CurrentPlayerColor;

                    FindAndChangePointColor(closeToPoint, InstantiatedLine.endColor);
                }
            }

            if (Input.GetMouseButton(0))
            {
                Vector3 closeToPoint = IsClickCloseToPoint();
                if (closeToPoint.z != -10000f && InstantiatedLine != null && !closeToPoint.Equals(StartMousePos))
                {
                    InstantiatedLine.SetPosition(1, new Vector3(closeToPoint.x, closeToPoint.y, 0f));
                    FindAndChangePointColor(closeToPoint, InstantiatedLine.startColor);
                    secondPointCandidate = closeToPoint;
                }
                else if (InstantiatedLine != null)
                {
                    if (secondPointCandidate.z != -10000f)
                    {
                        ReinstatePointColorToLast(InstantiatedLine.GetPosition(1));
                        secondPointCandidate = new Vector3(0f, 0f, -10000f);
                    }
                    mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
                    InstantiatedLine.SetPosition(1, new Vector3(mousePos.x, mousePos.y, 0f));
                }
            }

            if (Input.GetMouseButtonUp(0))
            {
                Vector3 closeToPoint = IsClickCloseToPoint();
                if (closeToPoint.z != -10000f && InstantiatedLine != null && !closeToPoint.Equals(StartMousePos))
                {
                    InstantiatedLine.SetPosition(1, new Vector3(closeToPoint.x, closeToPoint.y, 0f));
                    if (LineInList(AlreadyDrawnLineList, InstantiatedLine))
                    {
                        ReinstatePointColorToLast(InstantiatedLine.GetPosition(0));
                        ReinstatePointColorToLast(InstantiatedLine.GetPosition(1));
                        Destroy(InstantiatedLine.gameObject);
                    }
                    else
                    {
                        CurrentPlayerLine = InstantiatedLine;
                        SetCollider(CurrentPlayerLine);
                        FindAndChangePointColor(closeToPoint, InstantiatedLine.startColor);
                    }
                    InstantiatedLine = null;
                }
                else if (InstantiatedLine != null)
                {
                    ReinstatePointColorToLast(InstantiatedLine.GetPosition(0));
                    ReinstatePointColorToLast(InstantiatedLine.GetPosition(1));
                    Destroy(InstantiatedLine.gameObject);
                    InstantiatedLine = null;
                }
            }
        }

        else if (!IsLineGameState && !DialoguePanel.active && IsThisPlayersTurn && !SettingsPanel.active)
        {
            if (Input.GetMouseButtonDown(0))
            {
                mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
                Vector2 mousePos2D = new Vector2(mousePos.x, mousePos.y);

                RaycastHit2D hit = Physics2D.Raycast(mousePos2D, Vector2.zero);
                if (hit.collider != null)
                {
                    if (!LineInList(SelectedLines, hit.collider.GetComponent<LineRenderer>()))
                    {
                        LineRenderer selectedLine = Instantiate(LineGenerator).GetComponent<LineRenderer>();
                        LineRenderer realLine = hit.collider.GetComponent<LineRenderer>();


                        selectedLine.transform.SetParent(ParentObject.transform);
                        selectedLine.positionCount = 2;
                        selectedLine.SetPosition(0, realLine.GetPosition(0));
                        selectedLine.SetPosition(1, realLine.GetPosition(1));


                        SelectedLines.Add(selectedLine);

                        ColorLine(selectedLine, Color.green);
                    }
                }
            }
        }
    }

    public void SetRoom(string foundRoomId)
    {
        //szoba lekérése
        CurrentRoom = new Room();
        RoomId = foundRoomId;
        FirebaseBehaviour.GetRoom(RoomId);
    }

    public void SetRoomObjectAndNames(Room room)
    {
        CurrentRoom = room;
        SetGameFieldByDifficulty(CurrentRoom.difficulty);
        SetPlayerColorAndOpponentId();
        CheckIfPlayerIsNext();
        SetPlayerOneName(CurrentRoom.playerOneName);
        SetPlayerTwoName(CurrentRoom.playerTwoName);
        UnityMainThreadDispatcher.Instance().Enqueue(SetRoomGameState(CurrentRoom.gameState));

        FirebaseBehaviour.SetRoomOpponentInUserRoom(FirebaseUser.UserId, RoomId, GetOpponentName());
    }

    public IEnumerator SetRoomGameState(string gameState)
    {
        if (gameState != null && gameState != "" && CurrentRoom.currentPlayerId != FirebaseUser.UserId)
        {
            SetGameFieldByDifficulty(CurrentRoom.difficulty);

            GameData gameData = JsonUtility.FromJson<GameData>(gameState);
            if (gameData.currentLine != null)
            {
                Line lineFromJson = gameData.currentLine;
                LineRenderer lineRenderer = Instantiate(LineGenerator).GetComponent<LineRenderer>();
                Vector3 pointAFromJson = new Vector3(lineFromJson.pointAX, lineFromJson.pointAY);
                Vector3 pointBFromJson = new Vector3(lineFromJson.pointBX, lineFromJson.pointBY);
                Vector3 pointA = FindPointFromJson(Camera.main.WorldToScreenPoint(pointAFromJson));
                Vector3 pointB = FindPointFromJson(Camera.main.WorldToScreenPoint(pointBFromJson));
                lineRenderer.SetPosition(0, new Vector3(pointA.x, pointA.y, 0f));
                lineRenderer.SetPosition(1, new Vector3(pointB.x, pointB.y, 0f));
                lineRenderer.transform.SetParent(ParentObject.transform);
                ColorLine(lineRenderer, GetColorByInt(lineFromJson.color));
                SetCollider(lineRenderer);
                AlreadyDrawnLineList.Add(lineRenderer);
            }

            if (gameData.foundPolygon != null)
            {
                Color colorFromJson = Color.white;
                List<LineRenderer> polygonFromJson = new List<LineRenderer>();
                foreach (var line in gameData.foundPolygon)
                {
                    LineRenderer polyLine = Instantiate(LineGenerator).GetComponent<LineRenderer>();
                    Vector3 polyPointAFromJson = new Vector3(line.pointAX, line.pointAY);
                    Vector3 polyPointBFromJson = new Vector3(line.pointBX, line.pointBY);
                    Vector3 polyPointA = FindPointFromJson(Camera.main.WorldToScreenPoint(polyPointAFromJson));
                    Vector3 polyPointB = FindPointFromJson(Camera.main.WorldToScreenPoint(polyPointBFromJson));
                    polyLine.SetPosition(0, new Vector3(polyPointA.x, polyPointA.y, 0f));
                    polyLine.SetPosition(1, new Vector3(polyPointB.x, polyPointB.y, 0f));
                    polyLine.gameObject.SetActive(false);
                    polygonFromJson.Add(polyLine);
                    colorFromJson = GetColorByInt(line.color);
                }
                if (!PolygonAlreadyFound(polygonFromJson))
                {
                    if (colorFromJson == Color.red)
                    {
                        PlayerOnePointChanged(polygonFromJson.Count);
                    }
                    else
                        PlayerTwoPointChanged(polygonFromJson.Count);
                }

                ColorBaseLineListPolygon(polygonFromJson, colorFromJson);
                FoundPolygons.Add(polygonFromJson);
            }
        }
        yield return null;
    }

    public void DeleteLastLine()
    {
        if (IsLineGameState)
        {
            if (CurrentPlayerLine != null)
            {
                ReinstatePointColorToLast(CurrentPlayerLine.GetPosition(0));
                ReinstatePointColorToLast(CurrentPlayerLine.GetPosition(1));
                Destroy(CurrentPlayerLine.gameObject);
            }
            else
            {
                SSTools.ShowMessage("You didn't choose a line!", SSTools.Position.bottom, SSTools.Time.twoSecond);
            }
        }
        else if (!IsLineGameState)
        {
            if (SelectedLines.Count != 0)
            {
                LineRenderer selectedLine = SelectedLines[SelectedLines.Count - 1];
                ReinstatePointColorToLast(selectedLine.GetPosition(0));
                ReinstatePointColorToLast(selectedLine.GetPosition(1));
                Destroy(selectedLine.gameObject);
                SelectedLines.Remove(selectedLine);

                foreach (var line in SelectedLines)
                {
                    FindAndChangePointColor(line.GetPosition(0), Color.green);
                    FindAndChangePointColor(line.GetPosition(1), Color.green);
                }
            }
        }
    }

    public void SetGameState()
    {
        if (IsLineGameState && CurrentPlayerLine != null)
        {
            DisableAllButtons();
            GenericDialog dialog = GenericDialog.Instance();
            dialog.Message("Are you sure?");
            dialog.OnAccept(() =>
            {
                AlreadyDrawnLineList.Add(CurrentPlayerLine);
                ChangeGameStateInFireBase();
                InstantiatedLine = null;
                IsLineGameState = !IsLineGameState;
                GameStageLabel.text = polygonCheckStageLabel;
                CheckPolygonButton.SetActive(true);
                EnableAllButtons();
                dialog.Hide();
            });

            dialog.OnDecline(() =>
            {
                EnableAllButtons();
                dialog.Hide();
            });
            dialog.Show();
        }
        else if (CurrentPlayerLine != null)
        {
            DisableAllButtons();
            GenericDialog dialog = GenericDialog.Instance();
            dialog.Message("Are you sure?");
            dialog.OnAccept(() =>
            {
                int listLenght = SelectedLines.Count;
                for (int i = 0; i < listLenght; i++)
                {
                    DeleteLastLine();
                }
                ChangeGameStateInFireBase();
                CurrentPlayerLine = null;
                FirebaseBehaviour.ChangeRoomCurrentPlayer(RoomId, OpponentId);
                CurrentlyFoundPolygon.Clear();
                EnableAllButtons();
                dialog.Hide();
            });

            dialog.OnDecline(() =>
            {
                EnableAllButtons();
                dialog.Hide();
            });
            dialog.Show();
        }
        else
        {
            SSTools.ShowMessage("You didn't choose a line!", SSTools.Position.bottom, SSTools.Time.twoSecond);
        }
    }

    public void CheckIfPlayerGetsPoint()
    {
        if (SelectedLines.Count < 3)
        {
            ClearSelectedLines();
            SSTools.ShowMessage("You selected less than 3 lines!", SSTools.Position.bottom, SSTools.Time.twoSecond);
            return;
        }
        if (!LinesFormPolygon())
        {
            ClearSelectedLines();
            SSTools.ShowMessage("Not a polygon!", SSTools.Position.bottom, SSTools.Time.twoSecond);
            return;
        }
        if (PolygonAlreadyFound(SelectedLines))
        {
            ClearSelectedLines();
            SSTools.ShowMessage("Polygon already found!", SSTools.Position.bottom, SSTools.Time.twoSecond);
            return;
        }
        if (!LineInList(SelectedLines, CurrentPlayerLine))
        {
            ClearSelectedLines();
            SSTools.ShowMessage("Polygon not created by you!", SSTools.Position.bottom, SSTools.Time.twoSecond);
            return;
        }

        SSTools.ShowMessage("You got " + SelectedLines.Count + " points!", SSTools.Position.bottom, SSTools.Time.twoSecond);

        List<LineRenderer> newList = new List<LineRenderer>();
        DeepCopyList(newList, SelectedLines);
        FoundPolygons.Add(newList);
        CurrentlyFoundPolygon = newList;
        ChangeGameStateInFireBase();

        if (CurrentPlayerColor == Color.red)
        {
            PlayerOnePointChanged(SelectedLines.Count);
        }
        else
        {
            PlayerTwoPointChanged(SelectedLines.Count);
        }
        ColorBaseLineListPolygon(SelectedLines, CurrentPlayerColor);
        ClearSelectedLines();
    }

    public void PlayerOnePointChanged(int point)
    {
        int playerPoints = int.Parse(PlayerOnePoints.text) + point;
        PlayerOnePoints.text = (playerPoints).ToString();
        if (playerPoints >= 10)
        {
            EndGameDialog(PlayerOneName.text + " won!");
        }
    }

    public void PlayerTwoPointChanged(int point)
    {
        int playerPoints = int.Parse(PlayerTwoPoints.text) + point;
        PlayerTwoPoints.text = (playerPoints).ToString();
        if (playerPoints >= 10)
        {
            EndGameDialog(PlayerTwoName.text + " won!");
        }
    }

    public void OpenCloseSettings()
    {
        if (SettingsPanel.active)
        {
            SettingsPanel.SetActive(false);
            EnableAllButtons();
        }
        else
        {
            DisableAllButtons();
            SettingsPanel.SetActive(true);
        }
    }

    public void OnConcedeBtnClick()
    {
        DisableAllButtons();
        GenericDialog dialog = GenericDialog.Instance();
        dialog.Message("Are you sure?");
        dialog.OnAccept(() =>
        {
            conceded = true;
            EndGameDialog(GetOpponentName() + " won!");
            dialog.Hide();
        });

        dialog.OnDecline(() =>
        {
            EnableAllButtons();
            dialog.Hide();
        });
        dialog.Show();
    }

    public void OnToTheMainManuClick()
    {
        //leiratkozás a szoba eseményeiről
        FirebaseBehaviour.UnSubscribeToRoomState(RoomId);
        DisableAllButtons();
        GenericDialog dialog = GenericDialog.Instance();
        dialog.Message("Are you sure?");
        dialog.OnAccept(() =>
        {
            SaveExpandedGameData();
            SceneManager.LoadScene("MainActivity");
            dialog.Hide();
        });

        dialog.OnDecline(() =>
        {
            EnableAllButtons();
            dialog.Hide();
        });
        dialog.Show();
    }

    public void OpponentConceded()
    {
        if (!conceded)
        {
            EndGameDialog(FirebaseUser.DisplayName + " won!");
        }
    }

    public void SetRoomFromExpandedData(List<Line> lines, int pointOne, int pointTwo, int gameStage)
    {
        ExpandedGameData expandedGameData = new ExpandedGameData(lines, pointOne, pointTwo, gameStage);
        SetPlayerOneName(CurrentRoom.playerOneName);
        SetPlayerTwoName(CurrentRoom.playerTwoName);

        if (expandedGameData != null)
        {
            SetGameFieldByDifficulty(CurrentRoom.difficulty);
            PlayerOnePointChanged(expandedGameData.playerOnePoint);
            PlayerTwoPointChanged(expandedGameData.playerTwoPoint);

            foreach (var line in expandedGameData.drawLines)
            {
                LineRenderer lineRenderer = Instantiate(LineGenerator).GetComponent<LineRenderer>();
                Vector3 pointAFromJson = new Vector3(line.pointAX, line.pointAY);
                Vector3 pointBFromJson = new Vector3(line.pointBX, line.pointBY);
                Vector3 pointA = FindPointFromJson(Camera.main.WorldToScreenPoint(pointAFromJson));
                Vector3 pointB = FindPointFromJson(Camera.main.WorldToScreenPoint(pointBFromJson));
                lineRenderer.SetPosition(0, new Vector3(pointA.x, pointA.y, 0f));
                lineRenderer.SetPosition(1, new Vector3(pointB.x, pointB.y, 0f));
                lineRenderer.transform.SetParent(ParentObject.transform);
                ColorLine(lineRenderer, GetColorByInt(line.color));
                SetCollider(lineRenderer);
                AlreadyDrawnLineList.Add(lineRenderer);
            }
        }
    }

    public void SetPlayerColorAndOpponentId()
    {
        if (CurrentRoom.playerOneId == FirebaseUser.UserId)
        {
            OpponentId = CurrentRoom.playerTwoId;
            CurrentPlayerColor = Color.red;
        }
        else
        {
            OpponentId = CurrentRoom.playerOneId;
            CurrentPlayerColor = Color.blue;
        }
    }

    private void SetMultiplayerRoom()
    {
        //tegyük be a felhasználót, ha már bent van nem történik semmi, de így nem kell lekérdeznünk a firebase-től semmit
        //szoba keresése, belépés, gamestate beállítás, játék indítása, feliratkozás eseményekre
        FirebaseBehaviour.WriteNewUser(FirebaseUser.DisplayName, FirebaseUser.UserId);
        FirebaseBehaviour.FindRoom(FirebaseUser.UserId, FirebaseUser.DisplayName, GooglePlayAccount.Instance.Difficulty);
    }

    public IEnumerator PlayerChanged(string playerId)
    {
        CurrentRoom.currentPlayerId = playerId;
        if (playerId == FirebaseUser.UserId)
        {
            //engedjük lépni
            IsThisPlayersTurn = true;
            IsLineGameState = true;
            GameStageLabel.text = lineGameStateLabel;
            EnableAllButtons();
            LoadAnimation.enabled = false;

            SSTools.ShowMessage("Your turn!", SSTools.Position.bottom, SSTools.Time.oneSecond);
        }
        else
        {
            //ne engedjük lépni
            IsThisPlayersTurn = false;
            IsLineGameState = false;
            DisableAllButtons();
            GameStageLabel.text = opponentChoosingLineLabel;
            CheckPolygonButton.SetActive(false);
            LoadAnimation.enabled = true;

        }
        yield return null;
    }


    public void SetPlayerOneName(string displayName)
    {
        CurrentRoom.playerOneName = displayName;
        PlayerOneName.text = displayName;
    }

    public void SetPlayerTwoName(string displayName)
    {
        if (displayName != "Unknown" && displayName != FirebaseUser.DisplayName)
        {
            FirebaseBehaviour.SetRoomOpponentInUserRoom(FirebaseUser.UserId, RoomId, displayName);
            SSTools.ShowMessage(displayName + " joined!", SSTools.Position.bottom, SSTools.Time.twoSecond);
        }
        CurrentRoom.playerTwoName = displayName;
        PlayerTwoName.text = displayName;
    }

    private void CheckIfPlayerIsNext()
    {
        if (CurrentRoom.currentPlayerId == "Unknown" && !fromMatches)
        {
            CurrentRoom.currentPlayerId = FirebaseUser.UserId;
            FirebaseBehaviour.ChangeRoomCurrentPlayer(RoomId, FirebaseUser.UserId);
        }
        else if (CurrentRoom.currentPlayerId == FirebaseUser.UserId)
        {
            CurrentRoom.currentPlayerId = FirebaseUser.UserId;
            UnityMainThreadDispatcher.Instance().Enqueue(PlayerChanged(FirebaseUser.UserId));
        }
        else
        {
            CurrentRoom.currentPlayerId = OpponentId;
            UnityMainThreadDispatcher.Instance().Enqueue(PlayerChanged(OpponentId));
        }
    }

    private string GetOpponentName()
    {
        if (PlayerOneName.text != FirebaseUser.DisplayName)
        {
            return PlayerOneName.text;
        }
        return PlayerTwoName.text;
    }

    private void EndGameDialog(string message)
    {
        FirebaseBehaviour.RemoveRoom(RoomId, FirebaseUser.UserId, OpponentId);
        DialoguePanel.SetActive(true);
        DialogueText.text = message;
        DisableAllButtons();
        DialogueBtn.interactable = true;
    }

    private void ChangeGameStateInFireBase()
    {
        //a most hozzáadott vonal átalakítása
        Line simpleLine = new Line();
        if (CurrentPlayerLine != null)
        {
            int color = 0;
            if (CurrentPlayerLine.endColor == Color.red)
            {
                color = 1;
            }
            else if (CurrentPlayerLine.endColor == Color.blue)
            {
                color = 2;
            }
            simpleLine = new Line(CurrentPlayerLine.GetPosition(0).x, CurrentPlayerLine.GetPosition(0).y, CurrentPlayerLine.GetPosition(1).x, CurrentPlayerLine.GetPosition(1).y, color);
        }
        //egyesével adjuk át, a megtalált poly átalakítása
        List<Line> simplifiedPolygon = new List<Line>();
        if (CurrentlyFoundPolygon != null)
        {

            foreach (var line in CurrentlyFoundPolygon)
            {
                int color = 0;
                if (line.endColor == Color.red)
                {
                    color = 1;
                }
                else if (line.endColor == Color.blue)
                {
                    color = 2;
                }
                Line simplePolyLine = new Line(line.GetPosition(0).x, line.GetPosition(0).y, line.GetPosition(1).x, line.GetPosition(1).y, color);
                simplifiedPolygon.Add(simplePolyLine);
            }
        }
        else
            SSTools.ShowMessage("No Poly!", SSTools.Position.bottom, SSTools.Time.twoSecond);
        //felülírjuk a firebasees adatot
        GameData gameData = new GameData(simplifiedPolygon, simpleLine);
        string json = JsonUtility.ToJson(gameData);
        FirebaseBehaviour.ChangeRoomGameState(RoomId, json);
    }

    private void ColorBaseLineListPolygon(List<LineRenderer> polygon, Color color)
    {
        foreach (var baseLine in AlreadyDrawnLineList)
        {
            foreach (var line in polygon)
            {
                if (LinesAreEqual(baseLine, line))
                {
                    ColorLine(baseLine, color);
                }
            }
        }
    }

    private bool LinesAreEqual(LineRenderer baseLine, LineRenderer line)
    {
        if (LineContainsPoint(baseLine.GetPosition(0), line) && LineContainsPoint(baseLine.GetPosition(1), line))
        {
            return true;
        }
        return false;
    }

    private Color GetColorByInt(int color)
    {
        switch (color)
        {
            case 0: return Color.white;
            case 1: return Color.red;
            case 2: return Color.blue;
            default: return Color.white;
        }
    }

    private void ColorLine(LineRenderer line, Color color)
    {
        line.startColor = color;
        line.endColor = color;
        FindAndChangePointColor(line.GetPosition(0), color);
        FindAndChangePointColor(line.GetPosition(1), color);
    }

    private bool LinesFormPolygon()
    {
        foreach (var line in SelectedLines)
        {
            if (PointPresentInLineList(SelectedLines, line.GetPosition(0)) != 2
                || PointPresentInLineList(SelectedLines, line.GetPosition(1)) != 2)
            {
                return false;
            }
        }
        return true;
    }

    private int PointPresentInLineList(List<LineRenderer> list, Vector3 point)
    {
        int pointNumber = 0;
        foreach (var line in list)
        {
            if (LineContainsPoint(point, line))
            {
                pointNumber++;
            }
        }
        return pointNumber;
    }

    private void ClearSelectedLines()
    {
        int listLenght = SelectedLines.Count;
        for (int i = 0; i < listLenght; i++)
        {
            DeleteLastLine();
        }
        SelectedLines.Clear();
    }

    private void DeepCopyList(List<LineRenderer> listToCopyTo, List<LineRenderer> copiedList)
    {
        foreach (var line in copiedList)
        {
            LineRenderer copiedLine = Instantiate(LineGenerator).GetComponent<LineRenderer>();
            copiedLine.positionCount = 2;
            copiedLine.SetPosition(0, line.GetPosition(0));
            copiedLine.SetPosition(1, line.GetPosition(1));
            copiedLine.gameObject.SetActive(false);
            copiedLine.endColor = CurrentPlayerColor;
            copiedLine.startColor = CurrentPlayerColor;
            listToCopyTo.Add(copiedLine);
        }
    }

    private bool PolygonAlreadyFound(List<LineRenderer> newPolygon)
    {
        foreach (var polygon in FoundPolygons)
        {
            if (ListEquals(polygon, newPolygon))
            {
                return true;
            }
        }
        return false;
    }

    private bool ListEquals(List<LineRenderer> polygon, List<LineRenderer> selectedLines)
    {

        foreach (var line in selectedLines)
        {
            if (!LineInList(polygon, line))
            {
                return false;
            }
        }
        return true;
    }

    private bool LineInList(List<LineRenderer> list, LineRenderer line)
    {
        foreach (var lineInList in list)
        {
            if ((lineInList.GetPosition(0).Equals(line.GetPosition(0)) && lineInList.GetPosition(1).Equals(line.GetPosition(1)))
                || (lineInList.GetPosition(0).Equals(line.GetPosition(1)) && lineInList.GetPosition(1).Equals(line.GetPosition(0))))
            {
                return true;
            }
        }
        return false;
    }

    private bool FindAndChangePointColor(Vector3 other, Color color)
    {

        foreach (GameObject point in PointList)
        {
            if (PointsAreEqual(point.transform.position, Camera.main.WorldToScreenPoint(other)))
            {
                point.GetComponent<Image>().color = color;
                return true;
            }
        }
        return false;
    }

    private Vector3 FindPointFromJson(Vector3 pointFromJson)
    {
        foreach (var point in PointList)
        {
            Vector3 pointPos = point.transform.position;
            if (pointFromJson.x > pointPos.x - 80 && pointFromJson.x < pointPos.x + 80 && pointFromJson.y > pointPos.y - 80 && pointFromJson.y < pointPos.y + 80)
            {
                return Camera.main.ScreenToWorldPoint(pointPos);
            }
        }
        return new Vector3(0f, 0f, -10000f);
    }

    private bool PointsAreEqual(Vector3 pointA, Vector3 pointB)
    {
        float pointFloatX = pointA.x;
        float otherFloatX = pointB.x;
        float differenceX = Math.Abs(pointFloatX * .0001f);

        float pointFloatY = pointA.y;
        float otherFloatY = pointB.y;
        float differenceY = Math.Abs(pointFloatY * .0001f);

        if (Math.Abs(pointFloatX - (float)otherFloatX) <= differenceX && Math.Abs(pointFloatY - (float)otherFloatY) <= differenceY)
        {
            return true;
        }
        return false;
    }

    private void ReinstatePointColorToLast(Vector3 point)
    {
        FindAndChangePointColor(point, Color.white);
        for (int i = AlreadyDrawnLineList.Count - 1; i >= 0; i--)
        {
            Color commonPointColor;
            if (LineContainsPoint(point, AlreadyDrawnLineList[i]))
                commonPointColor = AlreadyDrawnLineList[i].endColor;
            else
            {
                commonPointColor = Color.white;
            }
            if (commonPointColor != Color.white)
            {
                FindAndChangePointColor(point, commonPointColor);
                return;
            }
        }
    }

    private bool LineContainsPoint(Vector3 point, LineRenderer line)
    {
        if (PointsAreEqual(Camera.main.WorldToScreenPoint(line.GetPosition(0)), Camera.main.WorldToScreenPoint(point))
            || PointsAreEqual(Camera.main.WorldToScreenPoint(line.GetPosition(1)), Camera.main.WorldToScreenPoint(point)))
            return true;
        return false;
    }

    private Vector3 IsClickCloseToPoint()
    {
        foreach (var point in PointList)
        {
            Vector3 pointPos = point.transform.position;
            Vector3 mousePos = Input.mousePosition;
            if (mousePos.x > pointPos.x - 80 && mousePos.x < pointPos.x + 80 && mousePos.y > pointPos.y - 80 && mousePos.y < pointPos.y + 80)
            {
                return Camera.main.ScreenToWorldPoint(pointPos);
            }
        }
        return new Vector3(0f, 0f, -10000f);
    }

    private void SetCollider(LineRenderer lineToCollide)
    {
        if (lineToCollide != null)
        {
            var startPos = lineToCollide.GetPosition(0);
            var endPos = lineToCollide.GetPosition(1);
            BoxCollider2D col = lineToCollide.GetComponent<BoxCollider2D>();
            float lineLength = Vector3.Distance(startPos, endPos);
            col.size = new Vector3(lineLength, 0.5f, 0.25f);
            Vector3 midPoint = (startPos + endPos) / 2;
            col.transform.position = midPoint;
            float angle = (Mathf.Abs(startPos.y - endPos.y) / Mathf.Abs(startPos.x - endPos.x));
            if ((startPos.y < endPos.y && startPos.x > endPos.x) || (endPos.y < startPos.y && endPos.x > startPos.x))
            {
                angle *= -1;
            }
            angle = Mathf.Rad2Deg * Mathf.Atan(angle);
            col.transform.Rotate(0, 0, angle);
        }
    }

    private void DisableAllButtons()
    {
        List<Button> foundBtns = new List<Button>(FindObjectsOfType<Button>());
        foreach (var button in foundBtns)
        {
            if (button.name != "SettingsBtn" && button.name != "DialogueBtn")
            {
                button.interactable = false;
            }
        }
    }

    private void EnableAllButtons()
    {
        List<Button> foundBtns = new List<Button>(FindObjectsOfType<Button>());
        foreach (var button in foundBtns)
        {
            button.interactable = true;
        }
    }

    private void SetGameFieldByDifficulty(int diffic)
    {
        if (PointList == null)
        {
            switch (diffic)
            {
                case 0:
                    SetGameField(GetEasyPointPositions());
                    break;
                case 1:
                    SetGameField(GetNormalPointPositions());
                    break;
                case 2:
                    SetGameField(GetExpertPointPositions());
                    break;
                default:
                    SetGameField(GetEasyPointPositions());
                    break;
            }
        }
    }

    private void SetGameField(List<Vector3> pointPositions)
    {
        PointList = new List<GameObject>();
        foreach (Vector3 pointPos in pointPositions)
        {
            GameObject point = Instantiate(PointGenerator);
            NewPoint = point.GetComponent<Image>();
            NewPoint.transform.SetParent(ParentObject.transform);
            NewPoint.transform.localPosition = pointPos;
            NewPoint.gameObject.transform.SetSiblingIndex(0);
            PointList.Add(point);
        }
    }

    private List<Vector3> GetEasyPointPositions()
    {
        return new List<Vector3>
        {
            new Vector3(300f, 300f, 0f),
            new Vector3(-300f, 300f, 0f),
            new Vector3(300f, -300f, 0f),
            new Vector3(-300f, -300f, 0f)
        };
    }

    private List<Vector3> GetNormalPointPositions()
    {
        return new List<Vector3>
        {
            new Vector3(-400f, 200f, 0f),
            new Vector3(-400f, -200f, 0f),
            new Vector3(400f, 200f, 0f),
            new Vector3(400f, -200f, 0f),
            new Vector3(0f, 400f, 0f),
            new Vector3(0f, -400f, 0f)
        };
    }

    private List<Vector3> GetExpertPointPositions()
    {
        return new List<Vector3>
        {
            new Vector3(-400f, 200f, 0f),
            new Vector3(-400f, -200f, 0f),
            new Vector3(400f, 200f, 0f),
            new Vector3(400f, -200f, 0f),

            new Vector3(-200f, 400f, 0f),
            new Vector3(-200f, -400f, 0f),
            new Vector3(200f, 400f, 0f),
            new Vector3(200f, -400f, 0f),
        };
    }

    private void SaveExpandedGameData()
    {
        //az összes vonal átalakítása
        List<Line> simplifiedAlreadyDrawnLineList = new List<Line>();
        if (AlreadyDrawnLineList != null && AlreadyDrawnLineList.Count >= 1)
        {
            foreach (var line in AlreadyDrawnLineList)
            {
                int color = 0;
                if (line.endColor == Color.red)
                {
                    color = 1;
                }
                else if (line.endColor == Color.blue)
                {
                    color = 2;
                }
                simplifiedAlreadyDrawnLineList.Add(new Line(line.GetPosition(0).x, line.GetPosition(0).y, line.GetPosition(1).x, line.GetPosition(1).y, color));
            }
        }
        int gameState = IsLineGameState ? 0 : 1;
        //felülírjuk a firebasees adatot
        ExpandedGameData expandedGameData = new ExpandedGameData(simplifiedAlreadyDrawnLineList, Int32.Parse(PlayerOnePoints.text), Int32.Parse(PlayerTwoPoints.text), gameState);
        string expandedGameDataJson = JsonUtility.ToJson(expandedGameData);
        FirebaseBehaviour.SaveExpandedGameDataToFireBase(RoomId, expandedGameDataJson);
    }
}

[System.Serializable]
class GameData
{
    [SerializeField]
    public List<Line> foundPolygon;
    [SerializeField]
    public Line currentLine;

    public GameData() { }

    public GameData(List<Line> foundPolygon, Line currentLine)
    {
        this.foundPolygon = foundPolygon;
        this.currentLine = currentLine;
    }
}

[System.Serializable]
class LineList
{
    [SerializeField]
    public List<Line> lines;

    public LineList()
    {
    }

    public LineList(List<Line> lines)
    {
        this.lines = lines;
    }
}

[System.Serializable]
public class Line
{
    [SerializeField]
    public float pointAX;
    [SerializeField]
    public float pointAY;
    [SerializeField]
    public float pointBX;
    [SerializeField]
    public float pointBY;
    [SerializeField]
    public int color;

    public Line()
    {
    }

    public Line(float pointAX, float pointAY, float pointBX, float pointBY, int color)
    {
        this.pointAX = pointAX;
        this.pointAY = pointAY;
        this.pointBX = pointBX;
        this.pointBY = pointBY;
        this.color = color;
    }
}
